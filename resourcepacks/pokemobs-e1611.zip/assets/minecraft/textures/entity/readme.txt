by Wooferscoots

https://www.planetminecraft.com/member/wooferscoots/

https://www.planetminecraft.com/texture-pack/pokemon-mobs/ is the offical download location

Some help from Voidatron