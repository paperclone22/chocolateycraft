# Giant
- Requires Origins 1.3.1+

## Powers

**Party-Sized**
You are slightly over 3 blocks tall, and almost 2 blocks wide.

**Brutish Charge** | Toggleable with primary |
You can walk into blocks below stone tools to break them.

**Power Jump**
You can crouch to charge your jump meter. Jumping at any time during this will reset it, but you'll jump much higher. At full charge, you jump high enough to activate your ground slam.

**Heavier Acrobatics**
You are highly resistant to fall damage, and falling from high distances unleashes an AoE ground slam attack.

**Heavily Armed**
You deal more damage, and have longer reach, but your attack cooldown is greatly increased.

**Gentle Giant**
When hit, you have a 50% chance to be slowed, and weakened temporarily.